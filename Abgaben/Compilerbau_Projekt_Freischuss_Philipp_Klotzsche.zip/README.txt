How to start the StupsCompiler:

java -jar sablecc.jar sablecc.scc
javac StupsCompiler.java
// java StupsCompiler <path to C#-testfile> e.g. for same directory:
java StupsCompiler minimal.cs


Lexing: done
Parsing: done
AST: done
Typechecking: heard of